/* eslint-disable react/prop-types */
import { connect } from "react-redux";

function Header(props) {
  const weather = props.weather;
  /*   const time = useState(new Date());
  const H = time.getHours() < 10 ? "0" + time.getHours() : time.getHours();
  const M =
    time.getMinutes() < 10 ? "0" + time.getMinutes() : time.getMinutes();
  const S =
    time.getSeconds() < 10 ? "0" + time.getSeconds() : time.getSeconds(); */

  return (
    <header className="container p-3 d-flex justify-content-between align-items-start">
      <div className="d-flex flex-column justify-content-center align-items-center">
        <h3 className="d-flex gap-2">
          <i className="bi bi-geo-alt-fill"></i> {weather.location.name} 
        </h3>
        {/* <p className="col-12 text-center">
          {H}:{M}:{S}
        </p> */}
        <span>
          {weather.location.localtime.split(" ")[0].split("-").join(" / ") +
            " (" +
            weather.location.localtime.split(" ")[1] +
            ")"}
        </span>
        <span>{}</span>
      </div>
      <h5>
        <i className="bi bi-gear-fill"></i>
      </h5>
    </header>
  );
}

function mapStateToProps(state) {
  return state;
}

export default connect(mapStateToProps, null)(Header);
