import { CURRENT_BY_CITY } from "./actions";

const initialState = {
  weather: {
    location: {
      name: "Casablanca",
      country: "Morocco",
      localtime: "2025-01-26 19:45",
    },
    current: {
      temp_c: 16.0,
      temp_f: 60.8,
      is_day: 0,
      condition: {
        text: "Clear",
        icon: "//cdn.weatherapi.com/weather/64x64/night/113.png",
      },
      wind_mph: 6.9,
      wind_kph: 11.2,
    },
  },
  weatherList: [
    {
      location: {
        name: "London",
        country: "England",
        localtime: "2025-01-26 19:45",
      },
      current: {
        temp_c: 16.0,
        temp_f: 60.8,
        is_day: 0,
        condition: {
          text: "Clear",
          icon: "//cdn.weatherapi.com/weather/64x64/night/113.png",
        },
        wind_mph: 6.9,
        wind_kph: 11.2,
      },
    },
    {
      location: {
        name: "Rabat",
        country: "Morocco",
        localtime: "2025-01-26 19:45",
      },
      current: {
        temp_c: 17.0,
        temp_f: 61.8,
        is_day: 0,
        condition: {
          text: "Clear",
          icon: "//cdn.weatherapi.com/weather/64x64/night/113.png",
        },
        wind_mph: 7.9,
        wind_kph: 15.2,
      },
    },
  ],
};

const search = (state, action) => {
  if (state.weatherList.find((e) => e.location.name === action.city))
    return state.weatherList.find((e) => e.location.name === action.city);
  else {
    return {
      location: {
        name: "Casablanca",
        country: "Morocco",
        localtime: "2025-01-26 19:45",
      },
      current: {
        temp_c: 16.0,
        temp_f: 60.8,
        is_day: 0,
        condition: {
          text: "Clear",
          icon: "//cdn.weatherapi.com/weather/64x64/night/113.png",
        },
        wind_mph: 6.9,
        wind_kph: 11.2,
      },
    };
  }
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case CURRENT_BY_CITY:
      return (state = {
        ...state,
        weather: search(state, action),
      });
    default:
      return state;
  }
}
